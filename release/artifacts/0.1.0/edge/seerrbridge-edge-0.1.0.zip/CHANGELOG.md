# Changelog

All notable user-facing changes to SeerrBridge will be documented in this file. This project attempts to follow [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) conventions and adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

- Placeholder for upcoming changes.

## [0.1.0] - 2025-11-15

- Initial tracked release.
